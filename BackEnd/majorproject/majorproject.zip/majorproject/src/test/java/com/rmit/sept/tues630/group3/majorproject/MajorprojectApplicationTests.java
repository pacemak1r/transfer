package com.rmit.sept.tues630.group3.majorproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MajorprojectApplicationTests {

    @Test
    void contextLoads() {
    }

}
