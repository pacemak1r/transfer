package com.rmit.sept.tues630.group3.majorproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MajorprojectApplication {

    public static void main(String[] args) {
        SpringApplication.run(MajorprojectApplication.class, args);
    }

}
