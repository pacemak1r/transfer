package com.rmit.sept.tues630.group3.majorproject.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import javax.persistence.Id;
import javax.validation.constraints.NotBlank;



@Entity
public class Account {

    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @NotBlank(message = "Your firstName is required")
    private String firstName;
    @NotBlank(message = "Your lastName is required")
    private String lastName;
    @NotBlank(message = "Your address is required")
    private String address;

    @Id
    private String username;
    private String password;
    private String email;

    private String ac_type;

    @JsonFormat(pattern = "^([0]{1}-[0-9]{9}$")
    @NotBlank(message = "Your phone number is required")
    private String phoneNumber;

    private String services;
    private double workingHours;
    private int workingDays;

    public Account(String un, String p) {
        this.username = un;
        this.password = p;
        this.ac_type = "Admin";
    }
    public Account(){

    }

    public Account(String un, String p,String ph, String serves, double workingHours, int workingDays) {
        this.username = un;
        this.password = p;
        this.ac_type = "Worker";
        this.services = serves;
        this.workingHours = workingHours;
        this.workingDays = workingDays;
        this.phoneNumber = ph;
    }

    public Account(String fn, String ln, String a, String c, String g, String ph ,String email) {
        this.firstName = fn;
        this.lastName = ln;
        this.address = a;
        this.email = email;
        this.phoneNumber = ph;
        this.ac_type = "Customer";
    }

    public void updateDetails(String fn, String ln, String a, String c, String g, String ph , String email) {
        this.firstName = fn;
        this.lastName = ln;
        this.address = a;
        this.email = email;
        this.phoneNumber = ph;
    }


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) { this.username = username; }
    public String getPassword() {
        return password;
    }

    public String getFirstName() {
        return firstName;
    }


    public String getLastName() {
        return lastName;
    }


    public String getAddress() {
        return address;
    }


    public String getEmail() {
        return email;
    }

    public String getAcType() {
        return ac_type;
    }

    public void setAc_type(String ac_type) {
        if(workingDays == 0){ this.ac_type = "Customer";}
        else if(services == null){this.ac_type = "Admin";}
        else{this.ac_type = "Worker";}

    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getServices() {
        return services;
    }

    public double getWorkingHours() {
        return workingHours;
    }

    public int getWorkingDays() {
        return workingDays;
    }
}
